package com.cis.constants;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConstantsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConstantsApplication.class, args);
	}
}
