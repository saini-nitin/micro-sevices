export class StorageModel {
    key: string;
    value: any;
}